matlab -r "bps_install('BPSv55_r20171126',uigetdir([matlabroot,'\\toolbox\\bps'], 'Please choose a directory for installation'));exit"
