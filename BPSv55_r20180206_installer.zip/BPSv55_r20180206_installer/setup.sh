matlab -r "bps_install('BPSv55_r20180206',uigetdir([matlabroot,'\\toolbox\\bps'], 'Please choose a directory for installation'));exit"
