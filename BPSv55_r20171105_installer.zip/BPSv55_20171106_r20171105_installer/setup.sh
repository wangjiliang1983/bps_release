matlab -r "bps_install('BPSv55_20171106_r20171105',uigetdir([matlabroot,'\\toolbox\\bps'], 'Please choose a directory for installation'));exit"
